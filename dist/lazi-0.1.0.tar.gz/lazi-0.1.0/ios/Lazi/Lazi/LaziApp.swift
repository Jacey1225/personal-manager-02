//
//  LaziApp.swift
//  Lazi
//
//  Created by Jacey Simpson on 9/1/25.
//

import SwiftUI

@main
struct LaziApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
