//
//  LaziTests.swift
//  LaziTests
//
//  Created by Jacey Simpson on 9/1/25.
//

import Testing
@testable import Lazi

struct LaziTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
