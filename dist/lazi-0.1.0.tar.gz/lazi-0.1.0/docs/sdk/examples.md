# SDK Examples

Complete, real-world examples using the Lazi SDK.

## Table of Contents

- [Basic Widget Creation](#basic-widget-creation)
- [Analytics Dashboard](#analytics-dashboard)
- [GitHub Integration](#github-integration)
- [Multi-Widget Project](#multi-widget-project)
- [Real-Time Data Widget](#real-time-data-widget)
- [Image Gallery Widget](#image-gallery-widget)

## Basic Widget Creation

Simple widget creation and management:

```python
import asyncio
import os
from lazi_sdk import WriteWidget
from dotenv import load_dotenv

load_dotenv()

async def create_simple_widget():
    """Create a basic widget"""
    
    # Initialize SDK
    widget = WriteWidget(
        token=os.getenv("LAZI_TOKEN"),
        user_id=os.getenv("LAZI_USER_ID")
    )
    
    # Create widget
    await widget.create_new(
        name="My First Widget",
        description="A simple example widget",
        size="medium",
        project_id="demo_project_001"
    )
    
    # Save
    await widget.save()
    
    print(f"✅ Widget created: {widget.current_widget.id}")
    print(f"   Name: {widget.current_widget.name}")
    print(f"   Size: {widget.current_widget.size}")

if __name__ == "__main__":
    asyncio.run(create_simple_widget())
```

## Analytics Dashboard

Create a dashboard widget that fetches real-time analytics:

```python
import asyncio
import os
from lazi_sdk import WriteWidget

async def create_analytics_dashboard():
    """Create analytics dashboard widget"""
    
    widget = WriteWidget(
        token=os.getenv("LAZI_TOKEN"),
        user_id=os.getenv("LAZI_USER_ID")
    )
    
    # Create widget
    await widget.create_new(
        name="Sales Analytics Dashboard",
        description="Real-time sales metrics and KPIs",
        size="extra_large",
        project_id=os.getenv("PROJECT_ID")
    )
    
    # Configure analytics endpoint
    await widget.post(
        endpoint="https://analytics.example.com/api/v1/dashboard",
        endpoint_data={
            "params": {
                "metrics": "revenue,users,conversion",
                "date_range": "last_7_days",
                "granularity": "daily"
            },
            "headers": {
                "Authorization": f"Bearer {os.getenv('ANALYTICS_TOKEN')}",
                "Content-Type": "application/json"
            },
            "refresh_interval": 300,  # Update every 5 minutes
            "logic": """
def process_data(widget_data, request, user):
    # Extract key metrics
    revenue = widget_data.get('revenue', {})
    users = widget_data.get('users', {})
    conversion = widget_data.get('conversion', {})
    
    # Calculate trends
    revenue_trend = revenue.get('current', 0) - revenue.get('previous', 0)
    user_growth = ((users.get('current', 0) - users.get('previous', 0)) / users.get('previous', 1)) * 100
    
    return {
        'kpis': {
            'revenue': {
                'value': f"${revenue.get('current', 0):,.2f}",
                'trend': 'up' if revenue_trend > 0 else 'down',
                'change': f"{abs(revenue_trend):,.2f}"
            },
            'users': {
                'value': users.get('current', 0),
                'growth': f"{user_growth:.1f}%"
            },
            'conversion_rate': {
                'value': f"{conversion.get('rate', 0):.2f}%",
                'status': 'good' if conversion.get('rate', 0) > 2.5 else 'needs_improvement'
            }
        },
        'charts': {
            'revenue_over_time': widget_data.get('revenue_timeline', []),
            'user_acquisition': widget_data.get('user_timeline', [])
        },
        'updated_at': widget_data.get('timestamp')
    }
            """
        }
    )
    
    # Attach dashboard logo
    await widget.attach_media(
        object_name="dashboard_logo.png",
        filename="./assets/company_logo.png"
    )
    
    await widget.save()
    print(f"✅ Analytics dashboard created: {widget.current_widget.id}")

asyncio.run(create_analytics_dashboard())
```

## GitHub Integration

Widget that displays GitHub repository statistics:

```python
import asyncio
import os
from lazi_sdk import WriteWidget

async def create_github_widget():
    """Create GitHub repository stats widget"""
    
    widget = WriteWidget(
        token=os.getenv("LAZI_TOKEN"),
        user_id=os.getenv("LAZI_USER_ID")
    )
    
    # GitHub repository details
    repo_owner = "Jacey1225"
    repo_name = "personal-manager-02"
    
    await widget.create_new(
        name=f"{repo_owner}/{repo_name}",
        description="GitHub repository statistics",
        size="large",
        project_id=os.getenv("PROJECT_ID")
    )
    
    await widget.post(
        endpoint=f"https://api.github.com/repos/{repo_owner}/{repo_name}",
        endpoint_data={
            "params": {},
            "headers": {
                "Accept": "application/vnd.github.v3+json",
                "Authorization": f"token {os.getenv('GITHUB_TOKEN')}"
            },
            "refresh_interval": 3600,  # Update hourly
            "logic": """
def process_data(widget_data, request, user):
    return {
        'repository': {
            'name': widget_data.get('full_name'),
            'description': widget_data.get('description'),
            'url': widget_data.get('html_url')
        },
        'stats': {
            'stars': widget_data.get('stargazers_count', 0),
            'forks': widget_data.get('forks_count', 0),
            'watchers': widget_data.get('watchers_count', 0),
            'open_issues': widget_data.get('open_issues_count', 0)
        },
        'metadata': {
            'language': widget_data.get('language'),
            'license': widget_data.get('license', {}).get('name', 'None'),
            'created_at': widget_data.get('created_at'),
            'updated_at': widget_data.get('updated_at')
        },
        'popularity': 'high' if widget_data.get('stargazers_count', 0) > 100 else 'moderate'
    }
            """
        }
    )
    
    await widget.save()
    print(f"✅ GitHub widget created: {widget.current_widget.id}")

asyncio.run(create_github_widget())
```

## Multi-Widget Project

Create multiple widgets for a single project:

```python
import asyncio
import os
from lazi_sdk import WriteWidget, ReadWidget

async def create_project_dashboard():
    """Create a complete dashboard with multiple widgets"""
    
    project_id = os.getenv("PROJECT_ID")
    token = os.getenv("LAZI_TOKEN")
    user_id = os.getenv("LAZI_USER_ID")
    
    widgets_config = [
        {
            "name": "Team Overview",
            "description": "Team members and roles",
            "size": "medium",
            "endpoint": "/api/v1/team/overview",
            "refresh": 0
        },
        {
            "name": "Recent Activity",
            "description": "Latest project updates",
            "size": "medium",
            "endpoint": "/api/v1/activity/recent",
            "refresh": 60
        },
        {
            "name": "Task Progress",
            "description": "Current sprint progress",
            "size": "large",
            "endpoint": "/api/v1/tasks/progress",
            "refresh": 300
        },
        {
            "name": "Quick Stats",
            "description": "Key project metrics",
            "size": "small",
            "endpoint": "/api/v1/stats/quick",
            "refresh": 180
        }
    ]
    
    created_widgets = []
    
    for config in widgets_config:
        widget = WriteWidget(token=token, user_id=user_id)
        
        await widget.create_new(
            name=config["name"],
            description=config["description"],
            size=config["size"],
            project_id=project_id
        )
        
        await widget.post(
            endpoint=config["endpoint"],
            endpoint_data={
                "params": {"project_id": project_id},
                "headers": {"Authorization": f"Bearer {token}"},
                "refresh_interval": config["refresh"],
                "logic": "def process_data(data, req, user): return data"
            }
        )
        
        await widget.save()
        created_widgets.append(widget.current_widget.id)
        print(f"✅ Created: {config['name']}")
    
    # Verify all widgets
    reader = ReadWidget(
        username=os.getenv("LAZI_USERNAME"),
        token=token,
        project_id=project_id
    )
    
    all_widgets = await reader.list_widgets()
    print(f"\n📊 Total widgets in project: {len(all_widgets)}")
    
    return created_widgets

asyncio.run(create_project_dashboard())
```

## Real-Time Data Widget

Widget with real-time stock market data:

```python
import asyncio
import os
from lazi_sdk import WriteWidget

async def create_stock_widget():
    """Create real-time stock ticker widget"""
    
    widget = WriteWidget(
        token=os.getenv("LAZI_TOKEN"),
        user_id=os.getenv("LAZI_USER_ID")
    )
    
    await widget.create_new(
        name="Stock Market Ticker",
        description="Real-time stock prices",
        size="medium",
        project_id=os.getenv("PROJECT_ID")
    )
    
    await widget.post(
        endpoint="https://api.marketdata.app/v1/stocks/quotes/AAPL,GOOGL,MSFT",
        endpoint_data={
            "params": {
                "format": "json"
            },
            "headers": {
                "Authorization": f"Bearer {os.getenv('MARKET_DATA_TOKEN')}"
            },
            "refresh_interval": 60,  # Update every minute
            "logic": """
def process_data(widget_data, request, user):
    stocks = []
    
    for quote in widget_data.get('quotes', []):
        symbol = quote.get('symbol')
        price = quote.get('last', 0)
        change = quote.get('change', 0)
        change_pct = quote.get('changepct', 0)
        
        stocks.append({
            'symbol': symbol,
            'price': f"${price:.2f}",
            'change': f"${change:.2f}",
            'change_percent': f"{change_pct:+.2f}%",
            'trend': 'up' if change > 0 else 'down' if change < 0 else 'flat',
            'volume': quote.get('volume', 0)
        })
    
    return {
        'stocks': stocks,
        'market_status': 'open' if widget_data.get('market_open') else 'closed',
        'last_updated': widget_data.get('timestamp')
    }
            """
        }
    )
    
    await widget.save()
    print(f"✅ Stock ticker created: {widget.current_widget.id}")

asyncio.run(create_stock_widget())
```

## Image Gallery Widget

Widget displaying an image gallery with media files:

```python
import asyncio
import os
from pathlib import Path
from lazi_sdk import WriteWidget

async def create_gallery_widget():
    """Create image gallery widget"""
    
    widget = WriteWidget(
        token=os.getenv("LAZI_TOKEN"),
        user_id=os.getenv("LAZI_USER_ID")
    )
    
    await widget.create_new(
        name="Product Gallery",
        description="Product images and media",
        size="extra_large",
        project_id=os.getenv("PROJECT_ID")
    )
    
    # Upload multiple images
    image_dir = Path("./product_images")
    
    if image_dir.exists():
        for image_file in image_dir.glob("*.{jpg,png,jpeg}"):
            print(f"Uploading {image_file.name}...")
            await widget.attach_media(
                object_name=image_file.name,
                filename=str(image_file)
            )
    
    # Configure gallery interaction
    await widget.post(
        endpoint="/api/v1/products/gallery",
        endpoint_data={
            "params": {
                "category": "electronics",
                "limit": 20
            },
            "headers": {},
            "refresh_interval": 0,  # Static gallery
            "logic": """
def process_data(widget_data, request, user):
    # Organize images into categories
    images = widget_data.get('images', [])
    
    return {
        'gallery': {
            'total_images': len(images),
            'categories': {
                'featured': [img for img in images if img.get('featured')],
                'new': [img for img in images if img.get('is_new')],
                'all': images
            }
        },
        'layout': 'grid',
        'thumbnail_size': 'medium'
    }
            """
        }
    )
    
    await widget.save()
    print(f"✅ Gallery widget created: {widget.current_widget.id}")
    print(f"   Total media files: {len(widget.current_widget.content)}")

asyncio.run(create_gallery_widget())
```

## Testing and Error Handling

Complete example with error handling:

```python
import asyncio
import os
from lazi_sdk import WriteWidget
from fastapi import HTTPException

async def robust_widget_creation():
    """Widget creation with comprehensive error handling"""
    
    try:
        # Validate environment
        required_vars = ["LAZI_TOKEN", "LAZI_USER_ID", "PROJECT_ID"]
        for var in required_vars:
            if not os.getenv(var):
                raise ValueError(f"Missing environment variable: {var}")
        
        # Initialize widget
        widget = WriteWidget(
            token=os.getenv("LAZI_TOKEN"),
            user_id=os.getenv("LAZI_USER_ID")
        )
        
        # Create widget
        await widget.create_new(
            name="Robust Widget",
            description="Widget with error handling",
            size="medium",
            project_id=os.getenv("PROJECT_ID")
        )
        
        # Save
        await widget.save()
        
        print(f"✅ Success! Widget ID: {widget.current_widget.id}")
        return widget.current_widget.id
        
    except ValueError as e:
        print(f"❌ Configuration error: {str(e)}")
        return None
        
    except HTTPException as e:
        if e.status_code == 401:
            print("❌ Authentication failed: Check your token")
        elif e.status_code == 403:
            print("❌ Permission denied: Insufficient scopes")
        elif e.status_code == 404:
            print("❌ Not found: Check your project ID")
        else:
            print(f"❌ HTTP error: {e.detail}")
        return None
        
    except Exception as e:
        print(f"❌ Unexpected error: {str(e)}")
        return None

asyncio.run(robust_widget_creation())
```

## Next Steps

- [Authentication Guide](authentication.md) - Learn more about OAuth2 authentication
- [Widget Management](widgets.md) - Detailed widget API documentation
- [Custom Endpoints](../advanced/custom-endpoints.md) - Create custom widget endpoints
