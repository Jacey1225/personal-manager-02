# Details

Date : 2025-09-03 20:51:21

Directory /Users/jaceysimpson/Vscode/personal-manager-02

Total : 21 files,  880 codes, 44 comments, 144 blanks, all 1068 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [api/app.py](/api/app.py) | Python | 14 | 0 | 4 | 18 |
| [api/schedule\_router.py](/api/schedule_router.py) | Python | 25 | 0 | 1 | 26 |
| [ios/Lazi/Lazi/Assets.xcassets/AccentColor.colorset/Contents.json](/ios/Lazi/Lazi/Assets.xcassets/AccentColor.colorset/Contents.json) | JSON | 11 | 0 | 1 | 12 |
| [ios/Lazi/Lazi/Assets.xcassets/AppIcon.appiconset/Contents.json](/ios/Lazi/Lazi/Assets.xcassets/AppIcon.appiconset/Contents.json) | JSON | 35 | 0 | 1 | 36 |
| [ios/Lazi/Lazi/Assets.xcassets/Contents.json](/ios/Lazi/Lazi/Assets.xcassets/Contents.json) | JSON | 6 | 0 | 1 | 7 |
| [ios/Lazi/Lazi/ContentView.swift](/ios/Lazi/Lazi/ContentView.swift) | Swift | 34 | 0 | 5 | 39 |
| [ios/Lazi/Lazi/LaziApp.swift](/ios/Lazi/Lazi/LaziApp.swift) | Swift | 9 | 6 | 3 | 18 |
| [ios/Lazi/Lazi/home/HomePage.swift](/ios/Lazi/Lazi/home/HomePage.swift) | Swift | 52 | 0 | 7 | 59 |
| [ios/Lazi/LaziTests/LaziTests.swift](/ios/Lazi/LaziTests/LaziTests.swift) | Swift | 6 | 7 | 5 | 18 |
| [ios/Lazi/LaziUITests/LaziUITests.swift](/ios/Lazi/LaziUITests/LaziUITests.swift) | Swift | 19 | 13 | 10 | 42 |
| [ios/Lazi/LaziUITests/LaziUITestsLaunchTests.swift](/ios/Lazi/LaziUITests/LaziUITestsLaunchTests.swift) | Swift | 18 | 8 | 8 | 34 |
| [proxy\_bypass.py](/proxy_bypass.py) | Python | 10 | 3 | 4 | 17 |
| [requirements.txt](/requirements.txt) | pip requirements | 6 | 0 | 1 | 7 |
| [src/TrainingSetup.py](/src/TrainingSetup.py) | Python | 92 | 0 | 12 | 104 |
| [src/google\_calendar/enable\_google\_api.py](/src/google_calendar/enable_google_api.py) | Python | 31 | 0 | 7 | 38 |
| [src/google\_calendar/handleEvents.py](/src/google_calendar/handleEvents.py) | Python | 193 | 6 | 18 | 217 |
| [src/manage\_projects/set\_project.py](/src/manage_projects/set_project.py) | Python | 48 | 0 | 11 | 59 |
| [src/set\_goals/manage\_goals.py](/src/set_goals/manage_goals.py) | Python | 0 | 0 | 1 | 1 |
| [src/structureData.py](/src/structureData.py) | Python | 104 | 1 | 18 | 123 |
| [src/structure\_model\_output.py](/src/structure_model_output.py) | Python | 120 | 0 | 19 | 139 |
| [src/test\_model\_accuracy.py](/src/test_model_accuracy.py) | Python | 47 | 0 | 7 | 54 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)