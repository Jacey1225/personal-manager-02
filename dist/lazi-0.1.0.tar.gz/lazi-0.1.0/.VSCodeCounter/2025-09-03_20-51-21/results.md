# Summary

Date : 2025-09-03 20:51:21

Directory /Users/jaceysimpson/Vscode/personal-manager-02

Total : 21 files,  880 codes, 44 comments, 144 blanks, all 1068 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 11 | 684 | 10 | 102 | 796 |
| Swift | 6 | 138 | 34 | 38 | 210 |
| JSON | 3 | 52 | 0 | 3 | 55 |
| pip requirements | 1 | 6 | 0 | 1 | 7 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 21 | 880 | 44 | 144 | 1,068 |
| . (Files) | 2 | 16 | 3 | 5 | 24 |
| api | 2 | 39 | 0 | 5 | 44 |
| ios | 9 | 190 | 34 | 41 | 265 |
| ios/Lazi | 9 | 190 | 34 | 41 | 265 |
| ios/Lazi/Lazi | 6 | 147 | 6 | 18 | 171 |
| ios/Lazi/Lazi (Files) | 2 | 43 | 6 | 8 | 57 |
| ios/Lazi/Lazi/Assets.xcassets | 3 | 52 | 0 | 3 | 55 |
| ios/Lazi/Lazi/Assets.xcassets (Files) | 1 | 6 | 0 | 1 | 7 |
| ios/Lazi/Lazi/Assets.xcassets/AccentColor.colorset | 1 | 11 | 0 | 1 | 12 |
| ios/Lazi/Lazi/Assets.xcassets/AppIcon.appiconset | 1 | 35 | 0 | 1 | 36 |
| ios/Lazi/Lazi/home | 1 | 52 | 0 | 7 | 59 |
| ios/Lazi/LaziTests | 1 | 6 | 7 | 5 | 18 |
| ios/Lazi/LaziUITests | 2 | 37 | 21 | 18 | 76 |
| src | 8 | 635 | 7 | 93 | 735 |
| src (Files) | 4 | 363 | 1 | 56 | 420 |
| src/google_calendar | 2 | 224 | 6 | 25 | 255 |
| src/manage_projects | 1 | 48 | 0 | 11 | 59 |
| src/set_goals | 1 | 0 | 0 | 1 | 1 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)