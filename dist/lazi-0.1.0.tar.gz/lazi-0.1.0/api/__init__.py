"""API package for Personal Manager."""
